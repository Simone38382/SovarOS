#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// VGA text mode buffer
static volatile uint16_t* vga_buffer = (uint16_t*)0xB8000;
static const int VGA_WIDTH = 80;
static const int VGA_HEIGHT = 25;

// Color codes
enum vga_color {
    VGA_COLOR_BLACK = 0,
    VGA_COLOR_WHITE = 15
};

// Convert color and character to VGA entry
static uint16_t vga_entry(unsigned char ch, uint8_t color) {
    return (uint16_t)ch | (uint16_t)color << 8;
}

// Clear the screen
void clear_screen() {
    for (int y = 0; y < VGA_HEIGHT; y++) {
        for (int x = 0; x < VGA_WIDTH; x++) {
            const size_t index = y * VGA_WIDTH + x;
            vga_buffer[index] = vga_entry(' ', VGA_COLOR_BLACK);
        }
    }
}

// Print a string to the screen
void kernel_print(const char* str) {
    static size_t row = 0;
    static size_t col = 0;

    for (size_t i = 0; str[i] != '\0'; i++) {
        if (str[i] == '\n') {
            row++;
            col = 0;
            continue;
        }

        const size_t index = row * VGA_WIDTH + col;
        vga_buffer[index] = vga_entry(str[i], VGA_COLOR_WHITE);
        col++;

        if (col >= VGA_WIDTH) {
            row++;
            col = 0;
        }
    }
}

// Kernel entry point
void kernel_main() {
    clear_screen();
    kernel_print("Welcome to SovarOS!\n");
    kernel_print("Kernel initialized successfully.\n");

    // Halt the system
    while(1) {}
}