# SovarOS Development Environment Setup

## Cross-Compiler Toolchain

### Automated Installation
Navigate to the `tools/` directory and run:
```bash
chmod +x install-cross-compiler.sh
./install-cross-compiler.sh