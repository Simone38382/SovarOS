# SovarOS

## Overview
SovarOS is a custom operating system developed from scratch, focusing on kernel development in C.

## Prerequisites
- Cross-compiler (i686-elf-gcc)
- NASM Assembler
- GRUB2 
- Make
- Qemu (for emulation)

## Development Setup
1. Install Cross-Compiler Toolchain
```bash
# Example for Ubuntu/Debian
sudo apt-get update
sudo apt-get install build-essential bison flex libgmp3-dev libmpc-dev libmpfr-dev texinfo
wget https://ftp.gnu.org/gnu/gcc/gcc-10.2.0/gcc-10.2.0.tar.gz
# (Additional cross-compiler setup steps)