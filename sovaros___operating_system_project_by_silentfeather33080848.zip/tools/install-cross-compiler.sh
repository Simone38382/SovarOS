#!/bin/bash

# SovarOS Cross-Compiler Installation Script

# Exit on any error
set -e

# Configuration
BINUTILS_VERSION="2.38"
GCC_VERSION="12.2.0"
TARGET="i686-elf"
INSTALL_PREFIX="$HOME/opt/cross"

# Create directories
mkdir -p "$INSTALL_PREFIX"
mkdir -p build-toolchain
cd build-toolchain

# Download prerequisites
echo "Downloading Binutils $BINUTILS_VERSION and GCC $GCC_VERSION..."
wget https://ftp.gnu.org/gnu/binutils/binutils-${BINUTILS_VERSION}.tar.gz
wget https://ftp.gnu.org/gnu/gcc/gcc-${GCC_VERSION}/gcc-${GCC_VERSION}.tar.gz

# Extract archives
tar -xzf binutils-${BINUTILS_VERSION}.tar.gz
tar -xzf gcc-${GCC_VERSION}.tar.gz

# Binutils Build
mkdir build-binutils
cd build-binutils
../binutils-${BINUTILS_VERSION}/configure \
    --target=$TARGET \
    --prefix="$INSTALL_PREFIX" \
    --with-sysroot \
    --disable-nls \
    --disable-werror
make -j$(nproc)
make install
cd ..

# GCC Prerequisites
cd gcc-${GCC_VERSION}
contrib/download_prerequisites
cd ..

# GCC Build
mkdir build-gcc
cd build-gcc
../gcc-${GCC_VERSION}/configure \
    --target=$TARGET \
    --prefix="$INSTALL_PREFIX" \
    --disable-nls \
    --enable-languages=c,c++ \
    --without-headers \
    --enable-multilib
make all-gcc -j$(nproc)
make all-target-libgcc -j$(nproc)
make install-gcc
make install-target-libgcc
cd ..

# Clean up
cd ..
rm -rf build-toolchain

echo "Cross-compiler toolchain for SovarOS installed successfully!"
echo "Add $INSTALL_PREFIX/bin to your PATH"