# SovarOS Cross-Compiler Toolchain

## Overview
This directory contains scripts and instructions for setting up the cross-compiler toolchain required for SovarOS development.

## Prerequisites
- bash
- wget
- tar
- build-essential
- libgmp-dev
- libmpc-dev
- libmpfr-dev

## Installation

### Using the Install Script
```bash
chmod +x install-cross-compiler.sh
./install-cross-compiler.sh